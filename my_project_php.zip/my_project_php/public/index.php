<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Ján Kuník - PHP Frameworks</title>
    </head>
    <body>
        <p>
            <?php
            
            class Model{
                public $string;
                
                public function __construct(){
                    $this->string = "Hello World!";
                }
                
                public function set_string($string){
                    $this->string = $string;
                }
                
                public function get_string(){
                    return $this->string;
                }
            }
            
            class View{
                private $model;
                private $controller;
                
                public function __construct($model, $controller){
                    $this->controller = $controller;
                    $this->model = $model;
                }
                
                public function output(){
                    return '<a href="index.php?action=mouseButtonPressed">' . $this->model->get_string() . '</a>';
                }
            }
            
            class Controller{
                private $model;
                
                public function __construct($model){
                    $this->model = $model;
                }
                
                public function clicked(){
                    $this->model->set_string("Update Hello World!");
                }
            }
            
            $model = new Model();
            $controller = new Controller($model);
            $view = new View($model, $conroller);

            if (isset($_GET['action']) && $_GET['action'] == 'mouseButtonPressed'){
                $controller->clicked();
            }

            echo $view->output();
            
            ?>
        </p>
    </body>
</html>